package com.test.ecample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResTfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
