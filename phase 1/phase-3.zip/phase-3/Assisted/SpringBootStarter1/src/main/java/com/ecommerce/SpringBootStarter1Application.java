package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStarter1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStarter1Application.class, args);
	}

}
